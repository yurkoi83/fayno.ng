<?php

declare(strict_types=1);

namespace Laravel\AgentDetector;

enum KnownAgent: string
{
    case Cursor = 'cursor';
    case Claude = 'claude';
    case Cowork = 'cowork';
    case Devin = 'devin';
    case Replit = 'replit';
    case Gemini = 'gemini';
    case Codex = 'codex';
    case V0 = 'v0';
    case AugmentCli = 'augment-cli';
    case Opencode = 'opencode';
    case Amp = 'amp';
    case Copilot = 'copilot';
    case Antigravity = 'antigravity';
    case Pi = 'pi';
    case Junie = 'junie';
    case KiroCli = 'kiro-cli';
    case Kimi = 'kimi';
    case Grok = 'grok';
    case Cline = 'cline';
    case Goose = 'goose';
    case OpenClaw = 'openclaw';
    case ZCode = 'zcode';
    case QwenCode = 'qwen-code';
    case Crush = 'crush';
    case Windsurf = 'windsurf';
    case Zed = 'zed';
    case Kiro = 'kiro';
    case Jules = 'jules';

    public function label(): string
    {
        return match ($this) {
            self::AugmentCli => 'Augment CLI',
            self::KiroCli => 'Kiro CLI',
            self::OpenClaw => 'OpenClaw',
            self::V0 => 'v0',
            self::ZCode => 'ZCode',
            self::QwenCode => 'Qwen Code',
            self::Zed => 'Zed Agent',
            default => ucfirst($this->value),
        };
    }
}
