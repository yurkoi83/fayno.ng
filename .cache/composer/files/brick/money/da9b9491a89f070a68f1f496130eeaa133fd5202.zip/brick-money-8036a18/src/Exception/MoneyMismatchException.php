<?php

declare(strict_types=1);

namespace Brick\Money\Exception;

use Brick\Money\Currency;
use RuntimeException;

use function sprintf;

/**
 * Exception thrown when a money is not in the expected currency or context.
 */
final class MoneyMismatchException extends RuntimeException implements MoneyException
{
    /**
     * @pure
     */
    public static function currencyMismatch(Currency $expected, Currency $actual): self
    {
        return new self(sprintf(
            'The monies do not share the same currency: expected %s, got %s.',
            $expected->getCurrencyCode(),
            $actual->getCurrencyCode(),
        ));
    }

    /**
     * @pure
     */
    public static function contextMismatch(string $method): self
    {
        return new self(sprintf(
            'The monies do not share the same context. ' .
            'If this is intended, use %s($money->toRational()) instead of %s($money).',
            $method,
            $method,
        ));
    }
}
