<?php

declare(strict_types=1);

namespace Brick\Money\Formatter;

use Brick\Money\Money;
use Brick\Money\MoneyFormatter;
use NumberFormatter;
use Override;

use function assert;

/**
 * Note that this formatter uses NumberFormatter, which internally represents values using floating point arithmetic,
 * so discrepancies can appear when formatting very large monetary values.
 */
final readonly class MoneyLocaleFormatter implements MoneyFormatter
{
    private bool $allowWholeNumber;

    private NumberFormatter $numberFormatter;

    /**
     * @param string $locale           The locale to format to, for example 'fr_FR' or 'en_US'.
     * @param bool   $allowWholeNumber Whether to allow formatting as a whole number if the amount has no fraction.
     *
     * @pure
     */
    public function __construct(string $locale, bool $allowWholeNumber = false)
    {
        $this->allowWholeNumber = $allowWholeNumber;
        $this->numberFormatter = new NumberFormatter($locale, NumberFormatter::CURRENCY);
    }

    /**
     * @pure
     */
    #[Override]
    public function format(Money $money): string
    {
        if ($this->allowWholeNumber && $money->getAmount()->strippedOfTrailingZeros()->getScale() === 0) {
            $scale = 0;
        } else {
            $scale = $money->getAmount()->getScale();
        }

        // @phpstan-ignore possiblyImpure.methodCall
        $this->numberFormatter->setAttribute(NumberFormatter::MIN_FRACTION_DIGITS, $scale);

        // @phpstan-ignore possiblyImpure.methodCall
        $this->numberFormatter->setAttribute(NumberFormatter::MAX_FRACTION_DIGITS, $scale);

        $formatted = $this->numberFormatter->formatCurrency(
            $money->getAmount()->toFloat(),
            $money->getCurrency()->getCurrencyCode(),
        );

        // @phpstan-ignore possiblyImpure.functionCall
        assert($formatted !== false);

        return $formatted;
    }
}
